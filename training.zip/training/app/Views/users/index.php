<!DOCTYPE html>
<html>
<head>
    <title>Customer Accounts</title>

    <link rel="stylesheet" href="<?= base_url('public/css/style.css') ?>">

<body>

<header>
    <h1>User Accounts</h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('/about') ?>">About</a>
        <a href="<?= base_url('/customers') ?>">Customers</a>
        <a href="<?= base_url('/users') ?>">Users</a>
    </nav>
</header>

<div class="container">

    <table>

        <thead>
            <tr>
                <th>Username</th>
                <th>Full Name</th>
                <th>Role</th>
            </tr>
        </thead>

        <tbody>

            <?php foreach ($users as $user): ?>

                <tr>
                    <td><?= $user['username'] ?></td>
                    <td><?= $user['full_name'] ?></td>
                    <td>
                        <span class="badge">
                            <?= $user['role'] ?>
                        </span>
                    </td>
                </tr>

            <?php endforeach; ?>

        </tbody>

    </table>

</div>

</body>
</html>