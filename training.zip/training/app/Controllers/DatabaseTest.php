<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\UserModel;

class DatabaseTest extends BaseController
{
    public function index()
    {
        $customerModel = new CustomerModel();
        $userModel = new UserModel();

        $data = [
            'customers' => $customerModel->findAll(),
            'users' => $userModel->findAll()
        ];

        return view('database_test', $data);
    }
}